import rclpy
from rclpy.node import Node

from rover_interfaces.msg import RoverStatus


class RoverPublisher(Node):

    def __init__(self):
        super().__init__('rover_status_publisher')

        self.publisher = self.create_publisher(
            RoverStatus,
            '/rover_status',
            10)

        # 2 Hz = every 0.5 seconds
        self.timer = self.create_timer(0.5, self.publish_status)

        self.battery = 100.0

    def publish_status(self):

        msg = RoverStatus()

        msg.battery_percentage = self.battery
        msg.velocity = 2.5
        msg.emergency_stop = False
        msg.mode = "AUTONOMOUS"

        self.publisher.publish(msg)

        self.get_logger().info(
            f'Battery={msg.battery_percentage}, '
            f'Velocity={msg.velocity}, '
            f'Stop={msg.emergency_stop}, '
            f'Mode={msg.mode}'
        )

        self.battery -= 1.0

        if self.battery < 0:
            self.battery = 100.0


def main(args=None):
    rclpy.init(args=args)

    node = RoverPublisher()

    rclpy.spin(node)

    node.destroy_node()
    rclpy.shutdown()


if __name__ == '__main__':
    main()
