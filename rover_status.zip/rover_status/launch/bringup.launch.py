from launch import LaunchDescription
from launch_ros.actions import Node


def generate_launch_description():
    return LaunchDescription([

        Node(
            package='rover_status',
            executable='publisher',
            name='q1_publisher'
        ),

        Node(
            package='rover_status',
            executable='subscriber',
            name='q1_subscriber'
        ),

        Node(
            package='rover_status_custom',
            executable='publisher',
            name='rover_status_publisher'
        ),

        Node(
            package='rover_status_custom',
            executable='subscriber',
            name='rover_status_subscriber'
        ),

    ])