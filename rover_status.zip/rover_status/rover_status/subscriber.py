import rclpy
from rclpy.node import Node

from std_msgs.msg import Float32
from std_msgs.msg import String
from std_msgs.msg import Bool


class RoverSubscriber(Node):

    def __init__(self):
        super().__init__('rover_status_subscriber')

        self.create_subscription(
            Float32,
            '/battery_level',
            self.battery_callback,
            10)

        self.create_subscription(
            String,
            '/rover_mode',
            self.mode_callback,
            10)

        self.create_subscription(
            Bool,
            '/emergency_stop',
            self.stop_callback,
            10)

    def battery_callback(self, msg):
        self.get_logger().info(f'Battery Level: {msg.data}')

    def mode_callback(self, msg):
        self.get_logger().info(f'Rover Mode: {msg.data}')

    def stop_callback(self, msg):
        self.get_logger().info(f'Emergency Stop: {msg.data}')


def main(args=None):
    rclpy.init(args=args)

    node = RoverSubscriber()

    rclpy.spin(node)

    node.destroy_node()
    rclpy.shutdown()


if __name__ == '__main__':
    main()
