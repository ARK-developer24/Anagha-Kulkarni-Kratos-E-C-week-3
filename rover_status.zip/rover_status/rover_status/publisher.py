import rclpy
from rclpy.node import Node

from std_msgs.msg import Float32
from std_msgs.msg import String
from std_msgs.msg import Bool


class RoverPublisher(Node):

    def __init__(self):
        super().__init__('rover_status_publisher')

        self.battery_pub = self.create_publisher(Float32, '/battery_level', 10)
        self.mode_pub = self.create_publisher(String, '/rover_mode', 10)
        self.stop_pub = self.create_publisher(Bool, '/emergency_stop', 10)

        self.timer = self.create_timer(1.0, self.publish_data)

        self.battery = 100.0

    def publish_data(self):
        battery_msg = Float32()
        battery_msg.data = self.battery

        mode_msg = String()
        mode_msg.data = "AUTONOMOUS"

        stop_msg = Bool()
        stop_msg.data = False

        self.battery_pub.publish(battery_msg)
        self.mode_pub.publish(mode_msg)
        self.stop_pub.publish(stop_msg)

        self.get_logger().info(
            f'Battery: {self.battery}% Mode: AUTONOMOUS Emergency: False'
        )

        self.battery -= 1

        if self.battery < 0:
            self.battery = 100.0


def main(args=None):
    rclpy.init(args=args)

    node = RoverPublisher()

    rclpy.spin(node)

    node.destroy_node()
    rclpy.shutdown()


if __name__ == '__main__':
    main()
