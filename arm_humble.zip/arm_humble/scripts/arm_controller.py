#!/usr/bin/env python3

import math
import threading

import rclpy
from rclpy.node import Node

from sensor_msgs.msg import JointState


class ArmController(Node):

    def __init__(self):

        super().__init__("arm_controller")

        self.publisher = self.create_publisher(
            JointState,
            "/joint_states",
            10
        )

        # Link lengths
        self.L1 = 0.35
        self.L2 = 0.35

        # Shoulder height from URDF
        self.shoulder_height = 0.17

        # Initial end-effector position
        self.current_x = 0.35
        self.current_y = 0.0
        self.current_z = 0.45

        # Last computed joint angles (base, shoulder, elbow).
        # The timer below keeps republishing these continuously so
        # TF never goes stale while we wait on input() in run().
        self.last_angles = (0.0, 0.0, 0.0)

        self.get_logger().info("Arm Controller Started")

        # Publish at 20 Hz so robot_state_publisher always has a fresh
        # /joint_states message and TF stays valid between user inputs.
        self.timer = self.create_timer(0.05, self.timer_callback)

    def timer_callback(self):
        base, shoulder, elbow = self.last_angles
        self.publish_joint_state(base, shoulder, elbow)

    def inverse_kinematics(self, x, y, z):

        base_yaw = math.atan2(y, x)

        r = math.sqrt(x * x + y * y)

        z = z - self.shoulder_height

        d = math.sqrt(r * r + z * z)

        print("\n----- IK -----")
        print(f"r = {r:.3f}")
        print(f"z = {z:.3f}")
        print(f"d = {d:.3f}")

        if d > (self.L1 + self.L2):
            return None

        if d < abs(self.L1 - self.L2):
            return None

        cos_elbow = (
            d * d
            - self.L1 * self.L1
            - self.L2 * self.L2
        ) / (2 * self.L1 * self.L2)

        cos_elbow = max(min(cos_elbow, 1.0), -1.0)

        elbow = math.acos(cos_elbow)

        k1 = self.L1 + self.L2 * math.cos(elbow)
        k2 = self.L2 * math.sin(elbow)

        shoulder = math.atan2(z, r) - math.atan2(k2, k1)

        print(f"Base      : {base_yaw:.3f}")
        print(f"Shoulder  : {shoulder:.3f}")
        print(f"Elbow     : {elbow:.3f}")

        return (
            base_yaw,
            shoulder,
            elbow
        )

    def publish_joint_state(self, base, shoulder, elbow):

        msg = JointState()

        msg.header.stamp = self.get_clock().now().to_msg()

        msg.name = [
            "base_yaw_joint",
            "shoulder_joint",
            "elbow_joint",
            "wrist_pitch_joint",
            "wrist_roll_joint",
            "gripper_servo_joint"
        ]

        msg.position = [
            base,
            shoulder,
            elbow,
            0.0,
            0.0,
            0.0
        ]

        self.publisher.publish(msg)

    def run(self):

        while rclpy.ok():

            print("\nCurrent End Effector Position")
            print(f"x = {self.current_x:.2f}")
            print(f"y = {self.current_y:.2f}")
            print(f"z = {self.current_z:.2f}")

            axis = input("\nEnter axis (x/y/z): ").lower()

            try:
                displacement = float(
                    input("Enter displacement (m): ")
                )

            except ValueError:

                print("Invalid number.")
                continue

            new_x = self.current_x
            new_y = self.current_y
            new_z = self.current_z

            if axis == "x":
                new_x += displacement

            elif axis == "y":
                new_y += displacement

            elif axis == "z":
                new_z += displacement

            else:
                print("Invalid axis.")
                continue

            angles = self.inverse_kinematics(
                new_x,
                new_y,
                new_z
            )

            if angles is None:

                print("\nTarget is outside reachable workspace.")
                continue

            # Store the new angles - the timer callback publishes
            # them continuously from here on, including while we're
            # blocked on input() waiting for the next command.
            self.last_angles = angles

            self.current_x = new_x
            self.current_y = new_y
            self.current_z = new_z


def main(args=None):

    rclpy.init(args=args)

    controller = ArmController()

    # Spin in a background thread so the timer (and therefore
    # /joint_states) keeps firing even while run() is blocked on
    # input(). Without this, the topic goes silent between commands
    # and TF for every non-fixed joint expires in RViz.
    spin_thread = threading.Thread(
        target=rclpy.spin,
        args=(controller,),
        daemon=True
    )
    spin_thread.start()

    try:
        controller.run()

    except KeyboardInterrupt:
        pass

    controller.destroy_node()

    rclpy.shutdown()


if __name__ == "__main__":
    main()
