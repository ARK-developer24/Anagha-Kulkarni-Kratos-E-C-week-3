import os
from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.substitutions import Command
from launch_ros.actions import Node
def generate_launch_description():
    # Package directory
    pkg_share = get_package_share_directory("arm_humble")
    # Paths
    xacro_file = os.path.join(
        pkg_share,
        "urdf",
        "my_custom_arm.urdf.xacro"
    )
    rviz_config_file = os.path.join(
        pkg_share,
        "rviz",
        "view_arm.rviz"
    )
    # Robot description
    robot_description = Command(
        ["xacro ", xacro_file]
    )
    # Robot State Publisher
    robot_state_publisher_node = Node(
        package="robot_state_publisher",
        executable="robot_state_publisher",
        output="screen",
        parameters=[
            {
                "robot_description": robot_description
            }
        ]
    )
    # NOTE: arm_controller_node (joint_state_publisher) has been removed.
    # It was publishing to /joint_states at the same time as
    # arm_ik_controller.py, so the two nodes were fighting over the topic
    # and the arm never held the pose your IK node commanded.
    # arm_ik_controller.py (run separately, not launched here) is now the
    # sole publisher of /joint_states.
    # RViz
    rviz2_node = Node(
        package="rviz2",
        executable="rviz2",
        name="rviz2",
        output="screen",
        arguments=[
            "-d",
            rviz_config_file
        ]
    )
    return LaunchDescription([
    robot_state_publisher_node,
    rviz2_node
    ])
